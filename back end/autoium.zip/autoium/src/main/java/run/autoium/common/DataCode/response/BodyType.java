package run.autoium.common.DataCode.response;


public interface BodyType {

    Integer NOBODY = -1;

    Integer JSON = 0;

    Integer HTML = 1;

    Integer XML = 2;

    Integer TEXT = 3;
}
