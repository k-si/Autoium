package run.autoium.common.DataCode;

/**
 * 对象的类型
 */
public interface ObjType {

    int empty = 0;

    int number = 1;

    int string = 2;

    int bool = 3;
}
