package run.autoium.common.DataCode;

public interface MethodType {

    Integer GET = 0;

    Integer POST = 1;

    Integer PUT = 2;

    Integer DELETE = 3;
}
