package run.autoium.common.DataCode.request;

/**
 * 要断言的内容
 */
public interface DataSourceType {

    int respCode = 0;

    int respHeader = 1;

    int respJson = 2;

    int respXml = 3;

    int respText = 4;
}
