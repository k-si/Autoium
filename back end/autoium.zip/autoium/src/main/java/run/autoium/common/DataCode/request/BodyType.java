package run.autoium.common.DataCode.request;

public interface BodyType {

    Integer NOBODY = -1;

    Integer JSON = 0;

    Integer FORM = 1;

    Integer FILE = 2;
}
